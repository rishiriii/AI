def transfer (x,y):
    if(x+y>3):
        x=x-(3-y)
        y=3
    else:
        y=y+x
        x=0
    return x,y

def dfs(x,y):
    st.append((x,y))
    if(x==2 or y==2):
        exit()

    while(st):
        x1,y1=st.pop()
        print('node',x1,y1)
        if(x1==2 or y1==2):
            visited.append((x1,y1))
            return
        elif(x1,y1)in visited:
            continue
        else:
            visited.append((x1,y1))

        if(x1==0):
            x=4
            st.append((x,y1))
        if(y1==3):
            y=0
            st.append((x1,y))

        if(x1>0 and y1<3):
            x,y=transfer(x1,y1)
            st.append((x,y))
        print("Stack ---->",st)
x=0
y=0
visited=[]
st=[]
st.append((x,y))
if x!=2 or y!=2:
    dfs(x,y)
print('solution:',visited)
