male(raj).
male(aayush).
doctor(raj).
engineer(aayush).
ltobehusband(X):-male(X),(doctor(X);engineer(X)).
rtobehusband(X):-((male(X),doctor(X));(male(X),engineer(X))).
