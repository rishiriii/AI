def moveTower(height,A,B,C):
    if height>=1:
        moveTower(height-1,A,C,B)
        moveDisk(height,A,B)
        moveTower(height-1,C,B,A)
def moveDisk(x,fp,tp):
    print("Disk= ",x, "from",fp,"to",tp)
moveTower(3,"A","B","C")
